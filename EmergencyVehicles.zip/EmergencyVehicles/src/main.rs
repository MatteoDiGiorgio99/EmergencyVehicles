use std::fmt;
use std::io;
/* Ipotizzo classificazione emergenze così:
    - 1 white
    - 2 green
    - 3 yellow
    - 4 red
*/

trait Vehicle: fmt::Display{
    fn get_id(&self) -> &str; 
    fn get_position(&self) -> (i32,i32);
    fn get_eqlevel(&self) -> i32;
    fn is_avaible(&self) -> bool;
    fn calc_destination_time(&self, destination:(i32,i32)) -> f32;
}

struct Ambulance{
    id:String,
    position:(i32,i32),
    eqlevel: i32,
    availabilty: bool,
}
impl Vehicle for Ambulance{
    fn get_id(&self)-> &str {
        &self.id
    }
    fn get_position(&self) ->(i32,i32){
        self.position
    }
    fn get_eqlevel(&self) -> i32{
        self.eqlevel
    }
    fn is_avaible(&self) -> bool{
        self.availabilty
    }
    fn calc_destination_time(&self,destination:(i32,i32)) -> f32 {
        let distance = (self.position.0 - destination.0).abs() as f32 + (self.position.1 - destination.1).abs() as f32; // Manhattan distance
        distance/100.0 //tempo ambulanza
    }
}

impl fmt::Display for Ambulance{
    fn fmt(&self,f: &mut fmt::Formatter<'_>)->fmt::Result{
        let mut code_emergency = "";
        if self.eqlevel == 1
        {
            code_emergency="White"
        }
        if self.eqlevel == 2
        {
            code_emergency="Green"
        }
        if self.eqlevel == 3
        {
            code_emergency="Yellow"
        }
        if self.eqlevel == 4
        {
            code_emergency="Red"
        }
        write!(f,"Ambulance {} at position ({},{}) --- Equipment Level {:?} --- Availability {}",self.id,self.position.0,self.position.1,code_emergency,self.availabilty)
    }
}


struct Helicopter{
    id:String,
    position:(i32,i32),
    eqlevel: i32,
    availabilty: bool,
}
impl Vehicle for Helicopter{
     fn get_id(&self)-> &str {
        &self.id
    }
    fn get_position(&self) ->(i32,i32){
        self.position
    }
    fn get_eqlevel(&self) -> i32{
        self.eqlevel
    }
    fn is_avaible(&self) -> bool{
        self.availabilty
    }
    fn calc_destination_time(&self, destination:(i32,i32))-> f32{
        let distance = ((self.position.0 - destination.0).pow(2) as f32 + (self.position.1 - destination.1).pow(2) as f32).sqrt();
        (distance/250.0)+5.0 //tempo elicottero
    }
}
  impl fmt::Display for Helicopter{
    fn fmt(&self,f: &mut fmt::Formatter<'_>)->fmt::Result{
        let mut code_emergency = "";
        if self.eqlevel == 1
        {
            code_emergency="White"
        }
        if self.eqlevel == 2
        {
            code_emergency="Green"
        }
        if self.eqlevel == 3
        {
            code_emergency="Yellow"
        }
        if self.eqlevel == 4
        {
            code_emergency="Red"
        }
        write!(f,"Helicoper {} at position ({},{}) --- Equipment Level {:?} --- Availability {}",self.id,self.position.0,self.position.1,code_emergency,self.availabilty)
    }
}

struct Fleet{
    vehicles: Vec<Box<dyn Vehicle>>, 
}
impl Fleet {
    fn new() -> Self{   
        Fleet{vehicles: Vec::new()}
    }
    fn add_vehicles(&mut self,vehicle:Box<dyn Vehicle>){
        self.vehicles.push(vehicle)
    }
    fn show_fleet(&self){
        for vehicle in &self.vehicles{
            println!("{}",vehicle)
        }
    }
    fn assign_vehicle(&self,destination: (i32,i32),request_eqlevel: i32)-> Option <&dyn Vehicle>{
        let mut quickest: Option<&dyn Vehicle> = None;
        let mut quick_response = f32::MAX; 

        for vehicle in &self.vehicles{
            if vehicle.get_eqlevel()>= request_eqlevel && vehicle.is_avaible(){
                let response_time = vehicle.calc_destination_time(destination);
                if response_time < quick_response{
                    quickest = Some(vehicle.as_ref());
                    quick_response = response_time;
                }
            }
        }
        quickest
    }
}

fn main() {
    println!("\n");

    let mut fleet = Fleet::new();

    loop {
        println!("Enter 'add' to add a vehicle,'screen' to show the fleet or 'emergency'(wanna exit? enter 'quit'):");
        let mut input = String::new();
        io::stdin()
            .read_line(&mut input)
            .expect("Failed to read line");

        match input.trim() {
            "add" => {
                println!("Enter vehicle type (Ambulance/Helicopter):");
                let mut vehicle_type = String::new();
                io::stdin()
                    .read_line(&mut vehicle_type)
                    .expect("Failed to read line");

                let vehicle_type = vehicle_type.trim();
                match vehicle_type {
                    "Ambulance" => {
                        let id = get_input("Enter ID:");
                        let position: (i32, i32) = (
                            get_input("Enter X coordinate:").parse().unwrap(),
                            get_input("Enter Y coordinate:").parse().unwrap(),
                        );
                        let eqlevel: i32 = loop {
                            let eqlevel_input: i32 = get_input("Enter equipment level (1-4):").parse().unwrap();
                            if eqlevel_input >= 1 && eqlevel_input <= 4 {
                                break eqlevel_input;
                            } else {
                                println!("Invalid equipment level. Please enter a number between 1 and 4.");
                            }
                        };
                        let availability: bool = loop {
                            let availability_input: String = get_input("Enter availability (true/false):");
                            match availability_input.trim().parse() {
                                Ok(value) => break value,
                                Err(_) => println!("Invalid availability. Please enter 'true' or 'false'."),
                            }
                        };

                        let ambulance = Box::new(Ambulance {
                            id,
                            position,
                            eqlevel,
                            availabilty: availability,
                        });
                        fleet.add_vehicles(ambulance);
                    }
                    "Helicopter" => {
                        let id = get_input("Enter ID:");
                        let position: (i32, i32) = (
                            get_input("Enter X coordinate:").parse().unwrap(),
                            get_input("Enter Y coordinate:").parse().unwrap(),
                        );
                        let eqlevel: i32 = loop {
                            let eqlevel_input: i32 = get_input("Enter equipment level (1-4):").parse().unwrap();
                            if eqlevel_input >= 1 && eqlevel_input <= 4 {
                                break eqlevel_input;
                            } else {
                                println!("Invalid equipment level. Please enter a number between 1 and 4.");
                            }
                        };
                        let availability: bool = loop {
                            let availability_input: String = get_input("Enter availability (true/false):");
                            match availability_input.trim().parse() {
                                Ok(value) => break value,
                                Err(_) => println!("Invalid availability. Please enter 'true' or 'false'."),
                            }
                        };

                        let helicopter = Box::new(Helicopter {
                            id,
                            position,
                            eqlevel,
                            availabilty: availability,
                        });
                        fleet.add_vehicles(helicopter);
                    }
                    _ => println!("Invalid vehicle type"),
                }
            }
            "screen" => fleet.show_fleet(),
            "emergency" => {
                let destination: (i32, i32) = (
                    get_input("Enter destination X coordinate:").parse().unwrap(),
                    get_input("Enter destination Y coordinate:").parse().unwrap(),
                );
                let request_eqlevel: i32 = loop {
                    let eqlevel_input: i32 = get_input("Enter emergency level (1-4):").parse().unwrap();
                    if eqlevel_input >= 1 && eqlevel_input <= 4 {
                        break eqlevel_input;
                    } else {
                        println!("Invalid emergency level. Please enter a number between 1 and 4.");
                    }
                };


                if let Some(vehicle) = fleet.assign_vehicle(destination, request_eqlevel) {
                    println!("\nQuickest available is: {}\n", vehicle)
                } else {
                    println!("\nSorry, no vehicles available for this level of emergency\n")
                }
            }
            "quit" => break,
            _ => {println!("Invalid command");}
        }
    }
}

fn get_input(prompt: &str) -> String {
    println!("{}", prompt);
    let mut input = String::new();
    io::stdin()
        .read_line(&mut input)
        .expect("Failed to read line");
    input.trim().to_string()
}
